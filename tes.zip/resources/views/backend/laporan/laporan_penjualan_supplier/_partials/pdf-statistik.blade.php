<div class="stats-container">
    <div class="stat-box">
        <div class="value">Rp {{ number_format($totalPendapatan, 0, ',', '.') }}</div>
        <div class="label">Total Pendapatan</div>
    </div>
    <div class="stat-box">
        <div class="value">{{ number_format($totalJenisProduk, 0, ',', '.') }}</div>
        <div class="label">Jenis Produk Terjual</div>
    </div>
    <div class="stat-box">
        <div class="value">{{ number_format($totalProdukTerjual, 0, ',', '.') }}</div>
        <div class="label">Produk Terjual</div>
    </div>
</div>
