<div class="header">
    <h1>Laporan Penjualan (by Supplier Terakhir)</h1>
    <p><strong>DISKON BESAR 22</strong></p>
    <p>Periode: {{ $start->translatedFormat('d F Y') }} - {{ $end->translatedFormat('d F Y') }}</p>
</div>
