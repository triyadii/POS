@include('backend.laporan.laporan_penjualan_supplier._partials.pdf-style')

<body>
    @include('backend.laporan.laporan_penjualan_supplier._partials.pdf-header')
    <main>
        @include('backend.laporan.laporan_penjualan_supplier._partials.pdf-table')
    </main>
</body>

</html>
