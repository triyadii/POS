@include('backend.laporan.laporan_penjualan_brand._partials.pdf-style')

<body>
    @include('backend.laporan.laporan_penjualan_brand._partials.pdf-header')
    <main>
        @include('backend.laporan.laporan_penjualan_brand._partials.pdf-statistik')
    </main>
</body>

</html>
