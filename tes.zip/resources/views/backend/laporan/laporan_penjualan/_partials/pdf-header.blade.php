<div class="header">
    <h1>Laporan Penjualan</h1>
    <p>Periode: {{ $start->translatedFormat('d F Y') }} - {{ $end->translatedFormat('d F Y') }}</p>
</div>
