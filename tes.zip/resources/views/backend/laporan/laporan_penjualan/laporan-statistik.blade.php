@include('backend.laporan.laporan_penjualan._partials.pdf-style')

<body>
    @include('backend.laporan.laporan_penjualan._partials.pdf-header')
    <main>
        @include('backend.laporan.laporan_penjualan._partials.pdf-statistik')
    </main>
</body>

</html>
